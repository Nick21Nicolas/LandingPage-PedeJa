const currentPage = window.location.pathname;

function acessarPerfil(tipo) {
  if (tipo === "cliente") {
    // Usa caminho relativo à raiz do projeto
    const basePath = window.location.pathname.includes('Tela_Entrada') ? '../' : '';
    window.location.href = basePath + "cliente/login.html";
  } else {
    // Usa caminho relativo à raiz do projeto
    const basePath = window.location.pathname.includes('Tela_Entrada') ? '' : 'Tela_Entrada/';
    window.location.href = basePath + `senha.html?perfil=${tipo}`;
  }
}

// Fluxo da página de senha dedicada ao admin
if (currentPage.includes("senha.html")) {
  const urlParams = new URLSearchParams(window.location.search);
  const perfil = urlParams.get("perfil") || "admin";

  const senhaCorreta = {
    admin: "admin123",
  };

  const titulo = document.getElementById("tituloSenha");
  if (titulo && perfil) {
    titulo.textContent = perfil === "admin" ? "Senha do Admin" : "Digite sua senha";
  }

  window.verificarSenha = function () {
    const senhaDigitada = document.getElementById("senhaInput").value;
    const erro = document.getElementById("erro");

    if (senhaCorreta[perfil] && senhaDigitada === senhaCorreta[perfil]) {
      // Após validar a senha, encaminha para o fluxo real do admin
      const basePath = window.location.pathname.includes('Tela_Entrada') ? '../' : '';
      window.location.href = basePath + "adm/login.html";
    } else {
      erro.textContent = "Senha incorreta!";
    }
  };

  // Permite enviar com Enter
  const senhaInput = document.getElementById("senhaInput");
  if (senhaInput) {
    senhaInput.addEventListener("keyup", (event) => {
      if (event.key === "Enter") {
        window.verificarSenha();
      }
    });
  }
}

//Esconder O Botão de ADMIN!!
document.addEventListener('keydown', function (e) {
  // Atalho: Ctrl + Shift + A
  if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'a') {
    const adminBtn = document.getElementById('adminBtn');
    if (adminBtn) {
      // Toggle visibility
      if (adminBtn.style.display === 'none' || getComputedStyle(adminBtn).display === 'none') {
        adminBtn.style.display = 'block';
      } else {
        adminBtn.style.display = 'none';
      }
    }
  }
});

// ===========================================
// 2) Toques na logo: 5 cliques/taps seguidos (mobile)
// ===========================================
let tapCount = 0;
const logoEl = document.getElementById('logo');

if (logoEl) {
  logoEl.addEventListener('click', function () {
    tapCount++;

    if (tapCount === 5) {
      tapCount = 0; // reseta contador

      const adminBtn = document.getElementById('adminBtn');
      if (adminBtn) {
        // Toggle visibility
        if (adminBtn.style.display === 'none' || getComputedStyle(adminBtn).display === 'none') {
          adminBtn.style.display = 'block';
        } else {
          adminBtn.style.display = 'none';
        }
      }
    }

    // Opcional: se quiser que o contador reinicie após 2 segundos sem novos toques:
    clearTimeout(logoEl._resetTimeout);
    logoEl._resetTimeout = setTimeout(() => {
      tapCount = 0;
    }, 2000);
  });
}
