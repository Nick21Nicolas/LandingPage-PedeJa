// supabase-client.js
// Importa Supabase para uso direto no navegador via ESM CDN
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

// Substitua pelos valores do seu projeto Supabase
// Vá em: Project Settings > API
const SUPABASE_URL = window.SUPABASE_URL || 'https://fuxahumlguzbumeyidhy.supabase.co';
const SUPABASE_ANON_KEY = window.SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZ1eGFodW1sZ3V6YnVtZXlpZGh5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIzMzQ4MTIsImV4cCI6MjA3NzkxMDgxMn0.nvHEvdeX4E9m00zpKq9SjjLYpPltPnECVuz0J8H1zRY';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
	autoRefreshToken: true,
	persistSession: true,
	detectSessionInUrl: true,
});

// Helpers de Auth
export function onAuthStateChange(callback) {
	return supabase.auth.onAuthStateChange((_event, session) => {
		const user = session?.user || null;
		callback(user);
	});
}

export async function getCurrentUser() {
	const { data } = await supabase.auth.getUser();
	return data?.user || null;
}

export async function signInWithEmailPassword(email, password) {
	return await supabase.auth.signInWithPassword({ email, password });
}

export async function signUpWithEmailPassword(email, password, userMetadata = {}) {
	return await supabase.auth.signUp({ email, password, options: { data: userMetadata } });
}

export async function signOut() {
	return await supabase.auth.signOut();
}

// DB helpers (tabelas equivalentes ao Firestore): produtos, pedidos, usuarios
export const tables = {
	produtos: 'produtos',
	pedidos: 'pedidos',
	usuarios: 'usuarios',
};
