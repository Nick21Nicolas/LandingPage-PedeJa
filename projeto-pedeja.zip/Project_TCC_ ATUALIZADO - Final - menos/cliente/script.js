// Função antiga para trocar de tela (caso você queira manter)
function irParaCadastro() {
  document.getElementById('telaLogin').classList.remove('visible');
  document.getElementById('telaLogin').classList.add('hidden');

  document.getElementById('telaCadastro').classList.remove('hidden');
  document.getElementById('telaCadastro').classList.add('visible');
}

function irParaLogin() {
  document.getElementById('telaCadastro').classList.remove('visible');
  document.getElementById('telaCadastro').classList.add('hidden');

  document.getElementById('telaLogin').classList.remove('hidden');
  document.getElementById('telaLogin').classList.add('visible');
}

// Exibir mensagem na tela em vez de alert
function mostrarMensagem(elemento, mensagem, tipo) {
const msgElement = document.getElementById(elemento);
if (msgElement) {
  msgElement.textContent = mensagem;
  msgElement.className = `mensagem ${tipo}`;
  msgElement.style.display = 'block';
  
  // Esconder a mensagem após 5 segundos
  setTimeout(() => {
    msgElement.style.display = 'none';
  }, 5000);
}
}

// Funções de autenticação
function cadastrarUsuario() {
const nome = document.getElementById('nome').value.trim();
const email = document.getElementById('email').value.trim();
const usuario = document.getElementById('usuario-cadastro').value.trim();
const senha = document.getElementById('senha-cadastro').value.trim();

// Validação básica
if (!nome || !email || !usuario || !senha) {
  mostrarMensagem('mensagem-cadastro', 'Por favor, preencha todos os campos!', 'erro');
  return;
}

// Verificar se o email é válido
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
if (!emailRegex.test(email)) {
  mostrarMensagem('mensagem-cadastro', 'Por favor, insira um email válido!', 'erro');
  return;
}

// Verificar se o usuário já existe (migrado para Auth/Firestore) - não usar localStorage
const usuarios = [];

if (usuarios.some(u => u.usuario === usuario)) {
  mostrarMensagem('mensagem-cadastro', 'Este nome de usuário já está em uso. Por favor, escolha outro.', 'erro');
  return;
}

// Adicionar novo usuário
usuarios.push({
  nome,
  email,
  usuario,
  senha
});

// Persistência de cadastro é feita pelo Firebase Auth + Firestore (clientes)

mostrarMensagem('mensagem-cadastro', 'Cadastro realizado com sucesso! Redirecionando para o login...', 'sucesso');

// Redirecionar após 2 segundos
setTimeout(() => {
  window.location.href = 'login.html';
}, 2000);
}

function fazerLogin() {
const usuario = document.getElementById('usuario-login').value.trim();
const senha = document.getElementById('senha-login').value.trim();

// Validação básica
if (!usuario || !senha) {
  mostrarMensagem('mensagem-login', 'Por favor, preencha todos os campos!', 'erro');
  return;
}

// Verificar credenciais via Firebase Auth (use cliente/login.html -> auth.js)
const usuarioEncontrado = null;

if (!usuarioEncontrado) {
  mostrarMensagem('mensagem-login', 'Usuário ou senha incorretos!', 'erro');
  return;
}

// Login e sessão são mantidos pelo Firebase Auth

mostrarMensagem('mensagem-login', 'Login realizado com sucesso! Redirecionando...', 'sucesso');

// Redirecionar para o cardápio
setTimeout(() => {
  window.location.href = 'cardapio.html';
}, 2000);
}

// Verificar se o usuário já está logado
function verificarLogin() {
const usuarioLogado = null;
if (usuarioLogado && window.location.pathname.includes('login.html')) {
  window.location.href = 'cardapio.html';
}
}

// Função para fazer logout
function fazerLogout() {
// Sessão é finalizada pelo Firebase Auth (ver auth.js)
window.location.href = 'login.html';
}

// Verificar autenticação na página de cardápio
function verificarAutenticacao() {
const usuarioLogado = null;

if (!usuarioLogado) {
  // Mostrar mensagem e redirecionar
  const msgContainer = document.createElement('div');
  msgContainer.className = 'mensagem-overlay';
  msgContainer.innerHTML = '<div class="mensagem-box erro">Você precisa fazer login para acessar esta página! Redirecionando...</div>';
  document.body.appendChild(msgContainer);
  
  setTimeout(() => {
    window.location.href = 'login.html';
  }, 2000);
  return;
}

// Exibir nome do usuário
const nomeUsuarioElement = document.getElementById('nome-usuario');
if (nomeUsuarioElement) {
  nomeUsuarioElement.textContent = `Bem-vindo, ${usuarioLogado.nome.split(' ')[0]}!`;
}
}

// Executar verificação quando a página carregar
document.addEventListener('DOMContentLoaded', function() {
  // Verificar se estamos na página de cardápio
  if (window.location.pathname.includes('cardapio.html')) {
    verificarAutenticacao();
  } else {
    verificarLogin();
  }
});