import { onAuthStateChange, signInWithEmailPassword, signUpWithEmailPassword, signOut as supaSignOut, getCurrentUser, supabase, tables } from "../supabase-client.js";

function getInputValue(id) {
  const el = document.getElementById(id);
  return el ? el.value.trim() : "";
}

export async function initAuthListeners() {
  onAuthStateChange(async (user) => {
    const nomeUsuarioElement = document.getElementById('nome-usuario');
    if (nomeUsuarioElement) {
      if (user) {
        try {
          // Buscar nome completo da tabela usuarios
          const { data, error } = await supabase
            .from(tables.usuarios)
            .select('nome, email')
            .eq('id', user.id)
            .single();
          
          if (!error && data && data.nome) {
            // Mostrar primeiro nome ou nome completo
            const primeiroNome = data.nome.split(' ')[0];
            nomeUsuarioElement.innerHTML = `<i class="fas fa-user-circle"></i> ${data.nome || primeiroNome}`;
          } else {
            // Fallback para email se não encontrar nome
            nomeUsuarioElement.innerHTML = `<i class="fas fa-user-circle"></i> ${user.email || 'Usuário'}`;
          }
        } catch (err) {
          // Em caso de erro, mostrar email
          nomeUsuarioElement.innerHTML = `<i class="fas fa-user-circle"></i> ${user.email || 'Usuário'}`;
        }
      } else {
        nomeUsuarioElement.innerHTML = '<i class="fas fa-user-circle"></i> Usuário';
      }
    }
  });
}

export async function loginCliente() {
  const email = getInputValue('usuario-login');
  const senha = getInputValue('senha-login');
  const { error } = await signInWithEmailPassword(email, senha);
  if (error) throw error;

  // Upsert do perfil no primeiro login
  const { data } = await supabase.auth.getUser();
  const user = data?.user || null;
  if (user) {
    try {
      await supabase
        .from(tables.usuarios)
        .upsert({ id: user.id, nome: user.user_metadata?.nome || '', email: user.email || email, tipo: 'cliente' });
    } catch (_) { /* noop */ }
  }

  window.location.href = 'cardapio.html';
}

export async function cadastrarCliente() {
  const email = getInputValue('email');
  const senha = getInputValue('senha-cadastro');
  const { error } = await signUpWithEmailPassword(email, senha);
  if (error) throw error;
  window.location.href = 'login.html';
}

export async function logout() {
  await supaSignOut();
  window.location.href = 'login.html';
}

export function authGuard(redirectTo = 'login.html') {
  onAuthStateChange((user) => {
    if (!user) {
      window.location.href = redirectTo;
    }
  });
}

export async function requireAdmin(redirectTo = '../Tela_Entrada/index.html') {
  return new Promise((resolve) => {
    onAuthStateChange(async (user) => {
      if (!user) {
        window.location.href = redirectTo;
        return resolve(false);
      }
      try {
        const { data, error } = await supabase
          .from(tables.usuarios)
          .select('tipo')
          .eq('id', user.id)
          .single();
        if (!error && data && data.tipo === 'admin') {
          return resolve(true);
        }
      } catch (_) {}
      window.location.href = redirectTo;
      return resolve(false);
    });
  });
}


