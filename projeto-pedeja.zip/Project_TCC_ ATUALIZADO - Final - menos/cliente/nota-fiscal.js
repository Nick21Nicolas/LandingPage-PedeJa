import { supabase, tables } from "../supabase-client.js";

document.addEventListener('DOMContentLoaded', async () => {
  const lista = document.getElementById('itensPedido');
  const totalSpan = document.getElementById('totalPedido');
  const numeroPedido = document.getElementById('numeroPedido');
  const dataPedido = document.getElementById('dataPedido');
  const metodoPagamento = document.getElementById('metodoPagamento');

  try {
    const url = new URL(window.location.href);
    const lastId = url.searchParams.get('pedidoId');
    if (!lastId) throw new Error('Pedido não encontrado');

    const { data, error } = await supabase
      .from(tables.pedidos)
      .select('*')
      .eq('id', lastId)
      .single();

    if (error) throw error;
    if (!data) throw new Error('Pedido não encontrado');

    const pedido = data;

    numeroPedido.textContent = String(lastId).substring(0, 8).toUpperCase();
    dataPedido.textContent = new Date().toLocaleString('pt-BR');
    metodoPagamento.textContent = pedido.pagamento || '-';

    let total = 0;
    (pedido.itens || []).forEach((item) => {
      const precoUnit = parseFloat(String(item.preco).replace('R$', '').replace(',', '.'));
      const subtotal = precoUnit * Number(item.quantidade || 1);
      total += subtotal;

      const linha = document.createElement('div');
      linha.classList.add('item-pedido');
      linha.innerHTML = `
        <div class="item-nome">${item.nome}</div>
        <div class="quantidade">${item.quantidade}x</div>
        <div class="item-preco">R$ ${subtotal.toFixed(2).replace('.', ',')}</div>
      `;
      lista.appendChild(linha);
    });

    totalSpan.textContent = `R$ ${total.toFixed(2).replace('.', ',')}`;
  } catch (err) {
    console.error(err);
    numeroPedido.textContent = '—';
    metodoPagamento.textContent = '—';
    totalSpan.textContent = 'R$ 0,00';
  }
});
