// Loads produtos do Supabase e retorna como array
import { supabase, tables } from "../supabase-client.js";

function formatCurrencyBRL(valorNumero) {
  if (typeof valorNumero === "string") return valorNumero;
  const numero = Number(valorNumero || 0);
  return `R$ ${numero.toFixed(2).replace('.', ',')}`;
}

async function fetchProdutos() {
  try {
    const { data, error } = await supabase
      .from(tables.produtos)
      .select('*')
      .order('nome', { ascending: true });
    if (error) throw error;

    const itens = (data || []).map((row) => {
      return {
        nome: row.nome || "Produto",
        descricao: row.descricao || "",
        preco: formatCurrencyBRL(row.preco),
        imagem: row.imagem || "",
        tipo: row.categoria || row.tipo || "comida",
        popular: Boolean(row.popular),
        expiraEm: null
      };
    });

    return itens;
  } catch (err) {
    console.error("Erro ao carregar produtos do Supabase:", err);
    return [];
  }
}

export { fetchProdutos };


