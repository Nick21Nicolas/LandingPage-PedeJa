// Importações no topo
import { supabase, getCurrentUser, tables } from "../supabase-client.js";

// Dados iniciais do carrinho
let carrinho = [];
let metodoPagamentoSelecionado = '';

// Função para renderizar o carrinho
function renderizarCarrinho() {
    const containerCarrinho = document.getElementById('itens-carrinho');
    
    // Carregar carrinho do localStorage
    carrinho = JSON.parse(localStorage.getItem('carrinho') || '[]');
    
    // Limpa o container
    containerCarrinho.innerHTML = '';
    
    if (carrinho.length === 0) {
        containerCarrinho.innerHTML = `
            <div class="empty-cart">
                <i class="fas fa-shopping-cart"></i>
                <p>Seu carrinho está vazio!</p>
                <a href="cardapio.html" class="btn-voltar">
                    <i class="fas fa-arrow-left"></i> Voltar ao Cardápio
                </a>
            </div>
        `;
    } else {
        // Adiciona cada item do carrinho
        carrinho.forEach((item, index) => {
            const precoNumerico = parseFloat(item.preco.replace('R$', '').replace(',', '.').trim());
            const subtotal = precoNumerico * item.quantidade;
            
            const itemEl = document.createElement('div');
            itemEl.className = 'cart-item';
            itemEl.innerHTML = `
                <img src="${item.imagem}" alt="${item.nome}" onerror="this.src='../assets/placeholder-food.png'">
                <div class="item-details">
                    <div class="item-title">${item.nome}</div>
                    <div class="item-price">${item.preco}</div>
                    <div class="item-quantity">
                        <button class="btn-quantity" onclick="alterarQuantidade(${index}, -1)">-</button>
                        <span>${item.quantidade}</span>
                        <button class="btn-quantity" onclick="alterarQuantidade(${index}, 1)">+</button>
                    </div>
                </div>
                <div class="item-subtotal">
                    R$ ${subtotal.toFixed(2).replace('.', ',')}
                </div>
                <button class="btn-remove" onclick="removerItem(${index})" title="Remover item">
                    <i class="fas fa-times"></i>
                </button>
            `;
            
            containerCarrinho.appendChild(itemEl);
        });
    }
    
    // Atualiza o valor total
    atualizarTotal();
}

// Função para calcular e atualizar o valor total
function atualizarTotal() {
    const valorTotal = carrinho.reduce((total, item) => {
        const precoNumerico = parseFloat(item.preco.replace('R$', '').replace(',', '.').trim());
        return total + (precoNumerico * item.quantidade);
    }, 0);
    
    document.getElementById('valor-total').textContent = `R$ ${valorTotal.toFixed(2).replace('.', ',')}`;
    
    // Atualiza o estado do botão finalizar
    const btnFinalizar = document.getElementById('btn-finalizar');
    btnFinalizar.disabled = !(carrinho.length > 0 && metodoPagamentoSelecionado);
}

// Função para alterar quantidade
function alterarQuantidade(index, delta) {
    // Carregar carrinho atual do localStorage
    carrinho = JSON.parse(localStorage.getItem('carrinho') || '[]');
    
    if (index < 0 || index >= carrinho.length) return;
    
    const novaQuantidade = carrinho[index].quantidade + delta;
    if (novaQuantidade < 1) return;
    
    carrinho[index].quantidade = novaQuantidade;
    localStorage.setItem('carrinho', JSON.stringify(carrinho));
    renderizarCarrinho();
    
    // Efeito visual de atualização
    const items = document.querySelectorAll('.cart-item');
    if (items[index]) {
        items[index].style.backgroundColor = 'rgba(39, 174, 96, 0.1)';
        setTimeout(() => {
            items[index].style.backgroundColor = '';
        }, 300);
    }
}

// Função para remover item
function removerItem(index) {
    // Carregar carrinho atual do localStorage
    carrinho = JSON.parse(localStorage.getItem('carrinho') || '[]');
    
    if (index < 0 || index >= carrinho.length) return;
    
    const itemEl = document.querySelectorAll('.cart-item')[index];
    
    if (itemEl) {
        // Animação de remoção
        itemEl.style.transform = 'translateX(100%)';
        itemEl.style.opacity = '0';
        
        setTimeout(() => {
            carrinho.splice(index, 1);
            localStorage.setItem('carrinho', JSON.stringify(carrinho));
            renderizarCarrinho();
        }, 300);
    } else {
        // Se não encontrou o elemento, apenas remove do array
        carrinho.splice(index, 1);
        localStorage.setItem('carrinho', JSON.stringify(carrinho));
        renderizarCarrinho();
    }
}

// Expor funções no escopo global para o onclick funcionar
window.alterarQuantidade = alterarQuantidade;
window.removerItem = removerItem;

// Função para selecionar método de pagamento
function selecionarMetodoPagamento(metodo) {
    metodoPagamentoSelecionado = metodo;
    
    // Atualiza a UI
    document.querySelectorAll('.payment-method').forEach(el => {
        el.classList.remove('selected');
        if (el.getAttribute('data-metodo') === metodo) {
            el.classList.add('selected');
            
            // Efeito visual
            el.style.transform = 'scale(1.02)';
            setTimeout(() => {
                el.style.transform = '';
            }, 200);
        }
    });
    
    // Atualiza o estado do botão finalizar
    atualizarTotal();
    
    // Atualiza o texto do botão
    const btnFinalizar = document.getElementById('btn-finalizar');
    btnFinalizar.innerHTML = `
        <i class="fas fa-check-circle"></i>
        Pagar com ${getMetodoPagamentoLabel(metodo)}
    `;
}

// Função para obter label do método de pagamento
function getMetodoPagamentoLabel(metodo) {
    const labels = {
        'dinheiro': 'Dinheiro',
        'cartao': 'Cartão',
        'pix': 'PIX'
    };
    return labels[metodo] || metodo;
}

// Função para finalizar o pedido
async function finalizarPedido() {
    if (carrinho.length === 0) {
        mostrarToast('Seu carrinho está vazio!', 'error');
        return;
    }
    
    if (!metodoPagamentoSelecionado) {
        mostrarToast('Por favor, selecione um método de pagamento!', 'error');
        return;
    }
    
    // Criar objeto do pedido
    const total = carrinho.reduce((total, item) => {
        const precoNumerico = parseFloat(item.preco.replace('R$', '').replace(',', '.').trim());
        return total + (precoNumerico * item.quantidade);
    }, 0);

    try {
        // Obter usuário atual
        const { data: userData, error: userError } = await supabase.auth.getUser();
        const user = userData?.user;
        
        // Usar o ID do usuário como identificador principal (mais seguro para RLS)
        const clienteId = user ? user.id : 'anonimo';
        const clienteEmail = user ? (user.email || '') : '';
        
        const pedido = {
            cliente: clienteId, // Salvar o ID do usuário para facilitar verificação RLS
            itens: carrinho,
            total: Number(total.toFixed(2)),
            pagamento: metodoPagamentoSelecionado,
            status: 'pendente'
        };
        
        console.log('Cliente ID:', clienteId);
        console.log('Cliente Email:', clienteEmail);

        console.log('Enviando pedido:', pedido);

        // Enviar para Supabase
        const { data, error } = await supabase
            .from(tables.pedidos)
            .insert(pedido)
            .select('id')
            .single();

        if (error) {
            console.error('Erro ao inserir pedido:', error);
            mostrarToast(`Erro ao finalizar o pedido: ${error.message || 'Erro desconhecido'}`, 'error');
            return;
        }

        const novoId = data?.id;
        console.log('Pedido criado com ID:', novoId);

        // Limpar carrinho local
        localStorage.removeItem('carrinho');
        carrinho = [];
        
        // Mostrar mensagem de sucesso
        mostrarToast('Pedido finalizado com sucesso! Redirecionando...', 'success');
        
        // Redirecionar para a página da nota fiscal após um breve delay
        setTimeout(() => {
            const idParam = novoId ? String(novoId) : '';
            window.location.href = `nota-fiscal.html?pedidoId=${encodeURIComponent(idParam)}`;
        }, 1200);
    } catch (err) {
        console.error('Erro ao finalizar pedido:', err);
        mostrarToast(`Erro ao finalizar o pedido: ${err.message || 'Erro desconhecido'}`, 'error');
    }
}

// Função para mostrar toast
function mostrarToast(mensagem, tipo = 'success') {
    // Remove toasts anteriores
    const toastsAntigos = document.querySelectorAll('.toast');
    toastsAntigos.forEach(toast => toast.remove());
    
    const toast = document.createElement('div');
    toast.className = `toast ${tipo}`;
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${tipo === 'success' ? 'var(--cantina-green)' : 'var(--cantina-red)'};
        color: white;
        padding: 15px 20px;
        border-radius: 10px;
        font-weight: 600;
        z-index: 2000;
        transform: translateX(400px);
        transition: transform 0.3s ease;
        box-shadow: 0 8px 32px rgba(0,0,0,0.3);
    `;
    
    toast.innerHTML = `
        <i class="fas fa-${tipo === 'success' ? 'check' : 'exclamation'}-circle"></i>
        ${mensagem}
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.transform = 'translateX(0)';
    }, 100);
    
    setTimeout(() => {
        toast.style.transform = 'translateX(400px)';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    // Renderiza o carrinho inicial
    renderizarCarrinho();
    
    // Adiciona event listeners para os métodos de pagamento
    document.querySelectorAll('.payment-method').forEach(el => {
        el.addEventListener('click', () => {
            const metodo = el.getAttribute('data-metodo');
            selecionarMetodoPagamento(metodo);
        });
    });
    
    // Adiciona event listener para o botão finalizar
    const btnFinalizar = document.getElementById('btn-finalizar');
    if (btnFinalizar) {
        btnFinalizar.addEventListener('click', finalizarPedido);
    }
});