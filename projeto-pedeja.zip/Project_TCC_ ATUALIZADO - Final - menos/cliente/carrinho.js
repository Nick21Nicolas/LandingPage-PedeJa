// Carrinho em memória com sincronização opcional no localStorage
const cartState = {
  items: JSON.parse(localStorage.getItem('carrinho')) || []
};

function saveCart() {
  localStorage.setItem('carrinho', JSON.stringify(cartState.items));
}

function findItemIndexByName(name) {
  return cartState.items.findIndex(i => i.nome === name);
}

function adicionarAoCarrinho(item) {
  const idx = findItemIndexByName(item.nome);
  if (idx !== -1) {
    cartState.items[idx].quantidade = (cartState.items[idx].quantidade || 1) + 1;
  } else {
    cartState.items.push({ ...item, quantidade: 1 });
  }
  saveCart();
  atualizarContadorCarrinho();
  return cartState.items;
}

function removerDoCarrinho(nome) {
  cartState.items = cartState.items.filter(i => i.nome !== nome);
  saveCart();
  atualizarContadorCarrinho();
  return cartState.items;
}

function alterarQuantidade(nome, quantidade) {
  if (quantidade < 1) return removerDoCarrinho(nome);
  const idx = findItemIndexByName(nome);
  if (idx !== -1) {
    cartState.items[idx].quantidade = quantidade;
    saveCart();
    atualizarContadorCarrinho();
  }
  return cartState.items;
}

function atualizarContadorCarrinho() {
  const contador = document.querySelector('.cart-count');
  if (!contador) return;
  const totalItens = cartState.items.reduce((total, item) => total + (item.quantidade || 1), 0);
  contador.textContent = totalItens;
  contador.style.display = totalItens > 0 ? 'flex' : 'none';
}

function abrirCarrinho() {
  if (!cartState.items.length) {
    alert('Seu carrinho está vazio!');
    return;
  }
  window.location.href = 'pagamento.html';
}

function inicializarBotoesPedir() {
  const botoesPedir = document.querySelectorAll('.btn-pedir');
  botoesPedir.forEach(botao => {
    botao.addEventListener('click', function() {
      const itemCard = this.closest('.item-cardapio');
      if (!itemCard) return;
      const nome = itemCard.querySelector('.item-titulo').textContent;
      const preco = itemCard.querySelector('.preco-valor').textContent.trim();
      const descricao = itemCard.querySelector('.item-descricao')?.textContent || '';
      const imagem = itemCard.querySelector('.item-img')?.src || '';
      adicionarAoCarrinho({ nome, preco, descricao, imagem });
      this.textContent = 'Adicionado!';
      this.style.backgroundColor = 'var(--accent)';
      this.style.color = 'white';
      setTimeout(() => {
        this.textContent = 'Pedir';
        this.style.backgroundColor = '';
        this.style.color = '';
      }, 1500);
    });
  });
}

document.addEventListener('DOMContentLoaded', function() {
  atualizarContadorCarrinho();
  inicializarBotoesPedir();
  setTimeout(inicializarBotoesPedir, 500);
  setTimeout(inicializarBotoesPedir, 1000);
});

// Expor funções globais usadas pelo HTML inline
window.adicionarAoCarrinho = adicionarAoCarrinho;
window.removerDoCarrinho = removerDoCarrinho;
window.alterarQuantidade = alterarQuantidade;
window.atualizarContadorCarrinho = atualizarContadorCarrinho;
window.abrirCarrinho = abrirCarrinho;