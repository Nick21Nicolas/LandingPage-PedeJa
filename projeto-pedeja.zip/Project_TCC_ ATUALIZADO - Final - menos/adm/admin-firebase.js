import { supabase, onAuthStateChange, tables } from "../supabase-client.js";

function parsePrecoBRLToNumber(precoStr) {
  if (typeof precoStr === 'number') return precoStr;
  if (!precoStr) return 0;
  return Number(String(precoStr).replace('R$', '').replace('.', '').replace(',', '.').trim()) || 0;
}

function formatCurrencyBRL(valorNumero) {
  const numero = Number(valorNumero || 0);
  return `R$ ${numero.toFixed(2).replace('.', ',')}`;
}

function ensurePedidosSection() {
  let sec = document.getElementById('pedidos-realtime');
  if (!sec) {
    const container = document.createElement('section');
    container.id = 'pedidos-realtime';
    container.style.maxWidth = '1000px';
    container.style.margin = '30px auto';
    container.innerHTML = `
      <h3 style="margin: 0 0 10px 0;"><i class="fas fa-receipt"></i> Pedidos em Tempo Real</h3>
      <div id="lista-pedidos" style="display: grid; gap: 12px;"></div>
    `;
    document.body.appendChild(container);
  }
}

function renderPedidoCard(id, pedido) {
  const itensResumo = (pedido.itens || []).map(i => `${i.quantidade || 1}x ${i.nome}`).join(', ');
  const card = document.createElement('div');
  card.style.background = '#fff';
  card.style.borderRadius = '10px';
  card.style.padding = '12px 14px';
  card.style.boxShadow = '0 0 10px rgba(0,0,0,0.08)';
  card.innerHTML = `
    <div style="display:flex; justify-content:space-between; align-items:center; gap:8px; flex-wrap: wrap;">
      <div>
        <div style="font-weight:700;">#${String(id).substring(0,8).toUpperCase()} • ${pedido.cliente || '-'}
          <span style="margin-left:8px; font-size:12px; padding:2px 8px; border-radius:999px; background:#f1f3f5;">${pedido.pagamento || '-'}</span>
        </div>
        <div style="color:#555; font-size:13px; margin-top:4px;">${itensResumo}</div>
      </div>
      <div style="display:flex; align-items:center; gap:6px;">
        <select data-id="${id}" class="status-select" style="padding:6px 8px; border-radius:6px; border:1px solid #ddd;">
          <option value="pendente" ${pedido.status === 'pendente' ? 'selected' : ''}>pendente</option>
          <option value="preparando" ${pedido.status === 'preparando' ? 'selected' : ''}>preparando</option>
          <option value="entregue" ${pedido.status === 'entregue' ? 'selected' : ''}>entregue</option>
        </select>
        <div style="font-weight:700; color:#27AE60;">${formatCurrencyBRL(pedido.total)}</div>
      </div>
    </div>
  `;
  return card;
}

function bindStatusHandlers(container) {
  container.querySelectorAll('.status-select').forEach((sel) => {
    sel.addEventListener('change', async (e) => {
      const pedidoId = e.target.getAttribute('data-id');
      try {
        const { error } = await supabase
          .from(tables.pedidos)
          .update({ status: e.target.value, atualizado_em: new Date().toISOString() })
          .eq('id', pedidoId);
        if (error) throw error;
      } catch (err) {
        console.error('Erro ao atualizar status:', err);
        alert('Erro ao atualizar status');
      }
    });
  });
}

async function carregarPedidos() {
  const lista = document.getElementById('lista-pedidos');
  if (!lista) return;
  const { data, error } = await supabase
    .from(tables.pedidos)
    .select('*')
    .order('created_at', { ascending: false });
  if (error) {
    console.error('Erro ao carregar pedidos:', error);
    return;
  }
  lista.innerHTML = '';
  (data || []).forEach((row) => {
    const card = renderPedidoCard(row.id, row);
    lista.appendChild(card);
  });
  bindStatusHandlers(lista);
}

function initRealtimePedidos() {
  ensurePedidosSection();
  carregarPedidos();

  const channel = supabase.channel('realtime-pedidos')
    .on('postgres_changes', { event: '*', schema: 'public', table: tables.pedidos }, (_payload) => {
      // Estratégia simples: recarregar a lista em qualquer mudança
      carregarPedidos();
    })
    .subscribe();

  // Opcional: guardar referência se precisar encerrar depois
  window.__supaRealtimePedidos = channel;
}

function initAddProdutoForm() {
  const form = document.getElementById('produto-form');
  if (!form) {
    // Tentar novamente após um pequeno delay se o formulário ainda não estiver disponível
    setTimeout(initAddProdutoForm, 100);
    return;
  }
  
  // Verificar se já tem um listener (evitar duplicação)
  if (form.dataset.listenerAdded === 'true') {
    return;
  }
  
  form.dataset.listenerAdded = 'true';
  
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    e.stopPropagation();
    
    try {
      const nome = form.nome.value.trim();
      const descricao = form.descricao.value.trim();
      const preco = parsePrecoBRLToNumber(form.preco.value.trim());
      const imagem = form.imagem.value.trim();
      const categoria = form.tipo.value;
      const popular = Boolean(form.popular.checked);
      
      if (!nome || !descricao || !preco || !imagem) {
        alert('Preencha todos os campos.');
        return;
      }
      
      const produtoId = window.getProdutoEditandoId ? window.getProdutoEditandoId() : null;
      
      if (produtoId) {
        // Atualizar produto existente
        const { error } = await supabase
          .from(tables.produtos)
          .update({ nome, descricao, preco, imagem, categoria, popular })
          .eq('id', produtoId);
        
        if (error) throw error;
        alert('Produto atualizado com sucesso!');
      } else {
        // Inserir novo produto
        const { error } = await supabase
          .from(tables.produtos)
          .insert({ nome, descricao, preco, imagem, categoria, popular });
        
        if (error) throw error;
        alert('Produto adicionado com sucesso!');
      }
      
      // Limpar formulário e atualizar lista
      if (window.limparFormulario) {
        window.limparFormulario();
      }
      
      // Atualizar lista de produtos
      if (window.atualizarListaProdutos) {
        await window.atualizarListaProdutos();
      }
      
    } catch (err) {
      console.error('Erro ao salvar produto no Supabase:', err);
      alert('Erro ao salvar no banco: ' + (err.message || 'Erro desconhecido'));
    }
  }, { once: false });
}

function guardAdmin() {
  onAuthStateChange(async (user) => {
    if (!user) {
      window.location.href = '../Tela_Entrada/index.html';
      return;
    }
    try {
      const { data, error } = await supabase
        .from(tables.usuarios)
        .select('tipo')
        .eq('id', user.id)
        .single();
      if (error || !data || data.tipo !== 'admin') {
        window.location.href = '../Tela_Entrada/index.html';
      }
    } catch (_) {
      window.location.href = '../Tela_Entrada/index.html';
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  guardAdmin();
  // Aguardar um pouco para garantir que admin.js já inicializou
  setTimeout(() => {
    initAddProdutoForm();
  }, 200);
  initRealtimePedidos();
});


