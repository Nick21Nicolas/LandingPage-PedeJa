// admin.js - Carrega e exibe produtos do Supabase
import { supabase, tables } from "../supabase-client.js";

let produtos = [];
let produtoEditandoId = null;

function formatCurrencyBRL(valorNumero) {
  if (typeof valorNumero === "string") return valorNumero;
  const numero = Number(valorNumero || 0);
  return `R$ ${numero.toFixed(2).replace('.', ',')}`;
}

function parsePrecoBRLToNumber(precoStr) {
  if (typeof precoStr === 'number') return precoStr;
  if (!precoStr) return 0;
  return Number(String(precoStr).replace('R$', '').replace(/\./g, '').replace(',', '.').trim()) || 0;
}

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("produto-form");
  const lista = document.getElementById("lista-produtos");
  const imagemUpload = document.getElementById("imagem-upload");
  const imagemInput = document.getElementById("imagem");
  const imagemPreview = document.getElementById("imagem-preview");

  // Função para converter imagem para Base64
  function converterImagemParaBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = error => reject(error);
    });
  }

  // Preview da imagem
  imagemUpload.addEventListener("change", async (e) => {
    const file = e.target.files[0];
    if (file) {
      try {
        const base64 = await converterImagemParaBase64(file);
        imagemInput.value = base64;
        imagemPreview.src = base64;
        imagemPreview.style.display = "block";
      } catch (error) {
        console.error("Erro ao converter imagem:", error);
        alert("Erro ao processar a imagem. Tente novamente.");
      }
    }
  });

  // Drag and drop
  const dropZone = document.querySelector('.imagem-upload-container');
  
  dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('drag-over');
  });

  dropZone.addEventListener('dragleave', (e) => {
    e.preventDefault();
    dropZone.classList.remove('drag-over');
  });

  dropZone.addEventListener('drop', async (e) => {
    e.preventDefault();
    dropZone.classList.remove('drag-over');
    
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
      try {
        const base64 = await converterImagemParaBase64(file);
        imagemInput.value = base64;
        imagemPreview.src = base64;
        imagemPreview.style.display = "block";
      } catch (error) {
        console.error("Erro ao converter imagem:", error);
        alert("Erro ao processar a imagem. Tente novamente.");
      }
    } else {
      alert("Por favor, arraste apenas arquivos de imagem.");
    }
  });

  // Preview quando URL é colada
  imagemInput.addEventListener("input", () => {
    const url = imagemInput.value;
    if (url.startsWith('http') || url.startsWith('data:image')) {
      imagemPreview.src = url;
      imagemPreview.style.display = "block";
    }
  });

  // Carregar produtos do Supabase
  async function carregarProdutos() {
    try {
      const { data, error } = await supabase
        .from(tables.produtos)
        .select('*')
        .order('nome', { ascending: true });
      
      if (error) throw error;
      
      produtos = (data || []).map(row => ({
        id: row.id,
        nome: row.nome || "",
        descricao: row.descricao || "",
        preco: formatCurrencyBRL(row.preco),
        precoNumero: row.preco,
        imagem: row.imagem || "",
        tipo: row.categoria || row.tipo || "comida",
        popular: Boolean(row.popular),
        expiraEm: null
      }));
      
      renderizarLista();
      atualizarEstatisticas();
    } catch (err) {
      console.error("Erro ao carregar produtos:", err);
      alert("Erro ao carregar produtos do banco de dados.");
    }
  }

  // Função para criar itens padrão do cardápio
  function criarItenspadrao() {
    const agora = new Date();
    const expiraPratoDoDia = new Date();
    expiraPratoDoDia.setHours(expiraPratoDoDia.getHours() + 24);

    return [
      // PRATO DO DIA
      {
        nome: "Feijoada Completa",
        descricao: "Feijoada tradicional com linguiça, bacon, costela e acompanhamentos. Servida com arroz, couve refogada, farofa e laranja.",
        preco: "R$ 28,90",
        imagem: "https://i.postimg.cc/nrG1JgPb/feijoada.jpg",
        tipo: "prato-do-dia",
        popular: true,
        expiraEm: expiraPratoDoDia.getTime()
      },

      // COMIDAS
      {
        nome: "Hambúrguer Artesanal",
        descricao: "Hambúrguer de carne 180g, queijo cheddar, alface, tomate, cebola roxa e molho especial da casa. Acompanha batata rústica.",
        preco: "R$ 24,90",
        imagem: "https://i.postimg.cc/Y9166Tkr/hambuguer.jpg",
        tipo: "comida",
        popular: true,
        expiraEm: null
      },
      {
        nome: "Pizza Margherita",
        descricao: "Pizza tradicional com molho de tomate, mussarela de búfala, manjericão fresco e azeite extravirgem.",
        preco: "R$ 32,90",
        imagem: "https://i.postimg.cc/T3FgZT3x/pizza.jpg",
        tipo: "comida",
        popular: false,
        expiraEm: null
      },
      {
        nome: "Lasanha à Bolonhesa",
        descricao: "Lasanha caseira com molho bolonhesa, presunto, queijo e molho branco. Gratinada no forno.",
        preco: "R$ 26,90",
        imagem: "https://canaldareceita.com.br/wp-content/uploads/2025/01/LASANHA-DE-CARNE-MOIDA-SIMPLES.jpg",
        tipo: "comida",
        popular: false,
        expiraEm: null
      },
      {
        nome: "Salmão Grelhado",
        descricao: "Filé de salmão grelhado com legumes no vapor e arroz de brócolis. Acompanha molho de ervas.",
        preco: "R$ 34,90",
        imagem: "https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=400&h=300&fit=crop",
        tipo: "comida",
        popular: true,
        expiraEm: null
      },
      {
        nome: "Tacos Mexicanos",
        descricao: "3 tacos com carne desfiada, guacamole, pico de gallo, queijo ralado e molho picante.",
        preco: "R$ 22,90",
        imagem: "https://upload.wikimedia.org/wikipedia/commons/thumb/7/73/001_Tacos_de_carnitas%2C_carne_asada_y_al_pastor.jpg/960px-001_Tacos_de_carnitas%2C_carne_asada_y_al_pastor.jpg",
        tipo: "comida",
        popular: false,
        expiraEm: null
      },

      // BEBIDAS
      {
        nome: "Suco de Laranja Natural",
        descricao: "Suco de laranja puro, espremido na hora. Rico em vitamina C e sem conservantes.",
        preco: "R$ 8,90",
        imagem: "https://images.unsplash.com/photo-1621506289937-a8e4df240d0b?w=400&h=300&fit=crop",
        tipo: "bebida",
        popular: true,
        expiraEm: null
      },
      {
        nome: "Refrigerante Coca-Cola",
        descricao: "Coca-Cola gelada 350ml. A bebida mais refrescante para acompanhar sua refeição.",
        preco: "R$ 5,90",
        imagem: "https://images.unsplash.com/photo-1554866585-cd94860890b7?w=400&h=300&fit=crop",
        tipo: "bebida",
        popular: false,
        expiraEm: null
      },
      {
        nome: "Água de Coco Gelada",
        descricao: "Água de coco natural, extraída na hora. Refrescante e hidratante.",
        preco: "R$ 6,90",
        imagem: "https://i.postimg.cc/9QFLWX2Y/coco.jpg",
        tipo: "bebida",
        popular: false,
        expiraEm: null
      },
      {
        nome: "Smoothie de Frutas Vermelhas",
        descricao: "Smoothie cremoso com morango, framboesa, mirtilo e iogurte natural. Rico em antioxidantes.",
        preco: "R$ 12,90",
        imagem: "https://i.postimg.cc/bYgbqxw6/smoothie.jpg",
        tipo: "bebida",
        popular: true,
        expiraEm: null
      },
      {
        nome: "Café Espresso Duplo",
        descricao: "Café espresso duplo encorpado, preparado com grãos selecionados e torrados na casa.",
        preco: "R$ 4,90",
        imagem: "https://postimg.cc/rDRJ2pv4",
        tipo: "bebida",
        popular: false,
        expiraEm: null
      },

      // DOCES
      {
        nome: "Brigadeiro Gourmet",
        descricao: "Brigadeiro artesanal feito com chocolate belga e granulado premium. Unidade.",
        preco: "R$ 3,50",
        imagem: "https://i.postimg.cc/2j1m5mkC/brigadeiro.jpg",
        tipo: "doce",
        popular: true,
        expiraEm: null
      },
      {
        nome: "Pudim de Leite Condensado",
        descricao: "Pudim cremoso feito com leite condensado e ovos frescos. Acompanha calda de caramelo.",
        preco: "R$ 9,90",
        imagem: "https://i.postimg.cc/bJjbwLbP/pudim.png",
        tipo: "doce",
        popular: false,
        expiraEm: null
      },
      {
        nome: "Cheesecake de Frutas Vermelhas",
        descricao: "Cheesecake cremoso com base de biscoito e cobertura de geleia de frutas vermelhas.",
        preco: "R$ 14,90",
        imagem: "https://i.postimg.cc/C5TvYjMb/cheesecake.jpg",
        tipo: "doce",
        popular: true,
        expiraEm: null
      },
      {
        nome: "Brownie com Sorvete",
        descricao: "Brownie de chocolate quente acompanhado de sorvete de baunilha e calda de chocolate.",
        preco: "R$ 12,90",
        imagem: "https://i.postimg.cc/Kvt6K8Cr/brownie.jpg",
        tipo: "doce",
        popular: false,
        expiraEm: null
      },
      {
        nome: "Sorvete Artesanal - 2 Bolas",
        descricao: "Duas bolas de sorvete artesanal. Sabores disponíveis: chocolate, baunilha, morango e pistache.",
        preco: "R$ 8,90",
        imagem: "https://i.postimg.cc/cHZgSCyN/sorvete.jpg",
        tipo: "doce",
        popular: false,
        expiraEm: null
      },
      {
        nome: "Petit Four Sortido",
        descricão: "Seleção de 6 petit fours variados: chocolate, morango, limão e maracujá. Perfeito para compartilhar.",
        preco: "R$ 16,90",
        imagem: "https://i.postimg.cc/hP4LmCYS/petit.jpg",
        tipo: "doce",
        popular: false,
        expiraEm: null
      }
    ];
  }

  // Função para adicionar itens padrão ao Supabase
  async function adicionarItensPadrao() {
    const itensPadrao = criarItenspadrao();
    try {
      for (const item of itensPadrao) {
        const precoNumero = parsePrecoBRLToNumber(item.preco);
        const { error } = await supabase
          .from(tables.produtos)
          .insert({
            nome: item.nome,
            descricao: item.descricao,
            preco: precoNumero,
            imagem: item.imagem,
            categoria: item.tipo,
            popular: item.popular
          });
        if (error) console.error(`Erro ao adicionar ${item.nome}:`, error);
      }
      await carregarProdutos();
      alert("Itens padrão adicionados com sucesso!");
    } catch (err) {
      console.error("Erro ao adicionar itens padrão:", err);
      alert("Erro ao adicionar itens padrão.");
    }
  }

  function renderizarLista() {
    if (!lista) return;
    lista.innerHTML = "";
    
    if (produtos.length === 0) {
      lista.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 40px; background: white; border-radius: 10px; max-width: 1000px; margin: 0 auto;">
          <h3>Nenhum item no cardápio</h3>
          <p>Adicione novos itens usando o formulário acima.</p>
        </div>
      `;
      return;
    }
    
    // Criar container de grid se não existir
    if (!lista.querySelector('.produtos-grid')) {
      const grid = document.createElement('div');
      grid.className = 'produtos-grid';
      grid.style.cssText = 'display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; max-width: 1000px; margin: 0 auto;';
      lista.appendChild(grid);
    }
    
    const grid = lista.querySelector('.produtos-grid');
    grid.innerHTML = '';
    
    produtos.forEach((item) => {
      const div = document.createElement("div");
      div.className = "item-admin";
      
      // Adicionar classe especial para prato do dia
      if (item.tipo === "prato-do-dia") {
        div.classList.add("prato-do-dia");
      }
      
      // Adicionar classe para itens populares
      if (item.popular) {
        div.classList.add("popular");
      }
      
      let expiraEmTexto = "";
      if (item.tipo === "prato-do-dia" && item.expiraEm) {
        const expiraEmData = new Date(item.expiraEm);
        const horasRestantes = Math.floor((item.expiraEm - new Date().getTime()) / (1000 * 60 * 60));
        expiraEmTexto = `<p class="expira">Expira em: ${horasRestantes}h (${expiraEmData.toLocaleString()})</p>`;
      }
      
      div.innerHTML = `
        <img src="${item.imagem}" alt="${item.nome}" onerror="this.src='https://via.placeholder.com/300x200?text=Sem+Imagem'" />
        <div>
          <h3>${item.nome}</h3>
          <p>${item.descricao}</p>
          <strong>${item.preco}</strong>
          <p class="tipo-produto">Tipo: ${getTipoLabel(item.tipo)}</p>
          ${item.popular ? '<p class="popular-tag">✓ Popular</p>' : ''}
          ${expiraEmTexto}
          <div class="acoes">
            <button onclick="editarProduto(${item.id})">Editar</button>
            <button onclick="removerProduto(${item.id})">Remover</button>
          </div>
        </div>
      `;
      grid.appendChild(div);
    });
  }
  
  function getTipoLabel(tipo) {
    const tipos = {
      'comida': 'Comida',
      'bebida': 'Bebida',
      'doce': 'Doce',
      'prato-do-dia': 'Prato do Dia'
    };
    return tipos[tipo] || 'Não especificado';
  }

  // Função para atualizar estatísticas
  function atualizarEstatisticas() {
    const estatisticas = document.getElementById("estatisticas");
    if (!estatisticas) return;
    
    const stats = {
      total: produtos.length,
      comida: produtos.filter(item => item.tipo === 'comida').length,
      bebida: produtos.filter(item => item.tipo === 'bebida').length,
      doce: produtos.filter(item => item.tipo === 'doce').length,
      pratoDoDia: produtos.filter(item => item.tipo === 'prato-do-dia').length,
      populares: produtos.filter(item => item.popular).length
    };
    
    estatisticas.innerHTML = `
      <div style="text-align: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">
        <div style="font-size: 24px; font-weight: bold; color: #d92323;">${stats.total}</div>
        <div style="font-size: 14px; color: #666;">Total de Itens</div>
      </div>
      <div style="text-align: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">
        <div style="font-size: 24px; font-weight: bold; color: #28a745;">${stats.comida}</div>
        <div style="font-size: 14px; color: #666;">Comidas</div>
      </div>
      <div style="text-align: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">
        <div style="font-size: 24px; font-weight: bold; color: #17a2b8;">${stats.bebida}</div>
        <div style="font-size: 14px; color: #666;">Bebidas</div>
      </div>
      <div style="text-align: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">
        <div style="font-size: 24px; font-weight: bold; color: #e83e8c;">${stats.doce}</div>
        <div style="font-size: 14px; color: #666;">Doces</div>
      </div>
      <div style="text-align: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">
        <div style="font-size: 24px; font-weight: bold; color: #ffc107;">${stats.pratoDoDia}</div>
        <div style="font-size: 14px; color: #666;">Prato do Dia</div>
      </div>
      <div style="text-align: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">
        <div style="font-size: 24px; font-weight: bold; color: #fd7e14;">${stats.populares}</div>
        <div style="font-size: 14px; color: #666;">Populares</div>
      </div>
    `;
  }

  // Expor função para admin-firebase.js acessar produtoEditandoId
  window.getProdutoEditandoId = () => produtoEditandoId;
  window.setProdutoEditandoId = (id) => { produtoEditandoId = id; };
  window.limparFormulario = () => {
    if (form) {
      form.reset();
      produtoEditandoId = null;
      if (window.setProdutoEditandoId) {
        window.setProdutoEditandoId(null);
      }
      if (imagemPreview) {
        imagemPreview.style.display = "none";
        imagemPreview.src = "";
      }
      const submitBtn = form.querySelector('button[type="submit"]');
      if (submitBtn) {
        submitBtn.textContent = 'Salvar Item';
      }
    }
  };

  // Funções para editar e remover produtos
  window.editarProduto = async (id) => {
    const item = produtos.find(p => p.id === id);
    if (!item) {
      alert("Produto não encontrado!");
      return;
    }
    
    // Definir ID do produto sendo editado
    produtoEditandoId = id;
    if (window.setProdutoEditandoId) {
      window.setProdutoEditandoId(id);
    }
    
    if (!form) {
      alert("Formulário não encontrado!");
      return;
    }
    
    form.nome.value = item.nome;
    form.descricao.value = item.descricao;
    form.preco.value = item.preco;
    form.imagem.value = item.imagem;
    form.tipo.value = item.tipo || "comida";
    form.popular.checked = item.popular || false;
    
    // Mostrar preview da imagem
    if (item.imagem && imagemPreview) {
      imagemPreview.src = item.imagem;
      imagemPreview.style.display = "block";
    }
    
    // Rolar para o formulário
    form.scrollIntoView({ behavior: 'smooth' });
    
    // Atualizar botão do formulário
    const submitBtn = form.querySelector('button[type="submit"]');
    if (submitBtn) {
      submitBtn.textContent = 'Atualizar Item';
    }
  };

  window.removerProduto = async (id) => {
    const item = produtos.find(p => p.id === id);
    if (!item) return;
    
    if (confirm(`Deseja realmente remover "${item.nome}" do cardápio?`)) {
      try {
        const { error } = await supabase
          .from(tables.produtos)
          .delete()
          .eq('id', id);
        
        if (error) throw error;
        
        await carregarProdutos();
        alert("Item removido com sucesso!");
      } catch (err) {
        console.error("Erro ao remover produto:", err);
        alert("Erro ao remover produto.");
      }
    }
  };

  // Função para limpar todo o cardápio
  window.limparCardapio = async () => {
    if (confirm("ATENÇÃO: Isso removerá TODOS os itens do cardápio. Confirma?")) {
      try {
        // Buscar todos os IDs primeiro
        const { data: todosProdutos, error: fetchError } = await supabase
          .from(tables.produtos)
          .select('id');
        
        if (fetchError) throw fetchError;
        
        if (todosProdutos && todosProdutos.length > 0) {
          // Deletar todos os produtos
          const ids = todosProdutos.map(p => p.id);
          const { error } = await supabase
            .from(tables.produtos)
            .delete()
            .in('id', ids);
          
          if (error) throw error;
        }
        
        await carregarProdutos();
        alert("Cardápio limpo com sucesso!");
      } catch (err) {
        console.error("Erro ao limpar cardápio:", err);
        alert("Erro ao limpar cardápio: " + (err.message || 'Erro desconhecido'));
      }
    }
  };

  // Função para restaurar itens padrão
  window.restaurarItenspadrao = async () => {
    if (confirm("Isso adicionará os itens padrão ao cardápio atual. Confirma?")) {
      await adicionarItensPadrao();
    }
  };

  // Expor função para atualizar lista (chamada por admin-firebase.js)
  window.atualizarListaProdutos = carregarProdutos;

  // Carregar produtos ao inicializar
  carregarProdutos();
  
  // Configurar listener para atualização em tempo real do Supabase
  const channel = supabase.channel('produtos-changes')
    .on('postgres_changes', { 
      event: '*', 
      schema: 'public', 
      table: tables.produtos 
    }, () => {
      carregarProdutos();
    })
    .subscribe();
});